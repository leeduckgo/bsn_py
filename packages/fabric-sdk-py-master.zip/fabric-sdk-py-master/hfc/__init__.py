from .version import VERSION  # noqa
