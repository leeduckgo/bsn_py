#!/usr/bin/env bash

cryptogen generate \
    --config e2e_cli/crypto-config.yaml \
    --output e2e_cli/crypto-config
