## Maintainers

| Name | Gerrit | GitHub | Chat | Email |
|---|---|---|---|---|
| Baohua Yang | baohua | yeasy | baohua | yangbaohua@gmail.com |
| Dong Wang |  MichaelWang | WandyLau | wangdong | xdragon007@gmail.com |
| Dixing Xu |  dexhunter | dexhunter | dexhunter | dixingxu@gmail.com |
| Guillaume Cisco | GuillaumeCisco | GuillaumeCisco | GuillaumeCisco | guillaumecisco@gmail.com |

## Retired Maintainers

| Name | Gerrit | GitHub | Chat | Email |
|---|---|---|---|---|
| Chang Chen | lafenicecc | lafenicecc | lafenicecc | ccchenbj@cn.ibm.com |
| David Dornseifer | david_dornseifer | dpdornseifer | david_dornseifer | dp.dornseifer@gmail.com |
| Chen Kai | grapebaba | grapebaba | grapebaba | 281165273@qq.com |

## License <a name="license"></a>

<a rel="license" href="http://creativecommons.org/licenses/by/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by/4.0/88x31.png" /></a><br />This document is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/4.0/">Creative Commons Attribution 4.0 International License</a>.
